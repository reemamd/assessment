# android-tmdb
An Android app using the [The Movie Database API](https://www.themoviedb.org/).

# Instructions
To run this app you need an API key from TMDb. Create a resource file called config.xml and add your key there.

    <resources>
        <string name="tmdb_api_key" templateMergeStrategy="preserve">tmdbApiKeyHere</string>
    </resources>